import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Route, Routes } from "react-router-dom";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { AppProvider } from "@/contexts/AppContext";
import Index from "./pages/Index.tsx";
import Times from "./pages/Times.tsx";
import Atletas from "./pages/Atletas.tsx";
import Eventos from "./pages/Eventos.tsx";
import Performance from "./pages/Performance.tsx";
import Financeiro from "./pages/Financeiro.tsx";
import Projetos from "./pages/Projetos.tsx";
import Mensagens from "./pages/Mensagens.tsx";
import Perfil from "./pages/Perfil.tsx";
import NotFound from "./pages/NotFound.tsx";

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <AppProvider>
    <TooltipProvider>
      <Toaster />
      <Sonner />
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<Index />} />
          <Route path="/times" element={<Times />} />
          <Route path="/atletas" element={<Atletas />} />
          <Route path="/eventos" element={<Eventos />} />
          <Route path="/performance" element={<Performance />} />
          <Route path="/financeiro" element={<Financeiro />} />
          <Route path="/projetos" element={<Projetos />} />
          <Route path="/mensagens" element={<Mensagens />} />
          <Route path="/perfil" element={<Perfil />} />
          <Route path="*" element={<NotFound />} />
        </Routes>
      </BrowserRouter>
    </TooltipProvider>
    </AppProvider>
  </QueryClientProvider>
);

export default App;
