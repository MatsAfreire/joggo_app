import { createContext, useContext, useState, ReactNode } from "react";

export type Modality = "Futebol" | "Basquete" | "Vôlei" | "Rugby" | "Handebol" | "Futsal";

export interface Team {
  id: string;
  name: string;
  category: string;
  modality: Modality;
  athletes: number;
}

export interface Athlete {
  id: string;
  name: string;
  category: string;
  position: string;
  status: "Em dia" | "Pendente";
  attendance: string;
  teamId?: string;
  modality?: Modality;
}

export interface Event {
  id: string;
  name: string;
  date: string;
  time: string;
  type: "Treino" | "Jogo" | "Reunião";
  team: string;
  modality?: Modality;
}

export interface Project {
  id: string;
  name: string;
  status: string;
  progress: number;
  deadline: string;
  partner: string;
}

export interface Message {
  id: string;
  title: string;
  to: string;
  date: string;
  preview: string;
}

export interface Payment {
  id: string;
  name: string;
  month: string;
  value: string;
  status: "Pago" | "Pendente" | "Atrasado";
}

interface AppContextType {
  teams: Team[];
  addTeam: (t: Omit<Team, "id">) => void;
  athletes: Athlete[];
  addAthlete: (a: Omit<Athlete, "id">) => void;
  events: Event[];
  addEvent: (e: Omit<Event, "id">) => void;
  projects: Project[];
  addProject: (p: Omit<Project, "id">) => void;
  messages: Message[];
  addMessage: (m: Omit<Message, "id">) => void;
  payments: Payment[];
  addPayment: (p: Omit<Payment, "id">) => void;
}

const AppContext = createContext<AppContextType | null>(null);

const uid = () => Math.random().toString(36).slice(2, 9);

const defaultTeams: Team[] = [
  { id: uid(), name: "JOGGO Sub-15", category: "Sub-15", modality: "Rugby", athletes: 14 },
  { id: uid(), name: "JOGGO Sub-20", category: "Sub-20", modality: "Rugby", athletes: 18 },
  { id: uid(), name: "JOGGO Adulto", category: "Adulto", modality: "Rugby", athletes: 22 },
  { id: uid(), name: "JOGGO Feminino", category: "Adulto", modality: "Futebol", athletes: 16 },
];

const defaultAthletes: Athlete[] = [
  { id: uid(), name: "Lucas Silva", category: "Sub-20", position: "Pilar", status: "Em dia", attendance: "92%", modality: "Rugby" },
  { id: uid(), name: "Pedro Santos", category: "Adulto", position: "Hooker", status: "Pendente", attendance: "78%", modality: "Rugby" },
  { id: uid(), name: "Ana Costa", category: "Sub-15", position: "Fullback", status: "Em dia", attendance: "95%", modality: "Rugby" },
  { id: uid(), name: "João Oliveira", category: "Adulto", position: "Fly-half", status: "Em dia", attendance: "88%", modality: "Rugby" },
  { id: uid(), name: "Maria Souza", category: "Sub-20", position: "Asa", status: "Pendente", attendance: "70%", modality: "Futebol" },
  { id: uid(), name: "Carlos Lima", category: "Sub-15", position: "Centro", status: "Em dia", attendance: "91%", modality: "Futebol" },
  { id: uid(), name: "Fernanda Rocha", category: "Adulto", position: "Ponta", status: "Em dia", attendance: "85%", modality: "Basquete" },
  { id: uid(), name: "Rafael Mendes", category: "Sub-20", position: "Scrum-half", status: "Pendente", attendance: "65%", modality: "Vôlei" },
];

const defaultEvents: Event[] = [
  { id: uid(), name: "Treino Tático", date: "10 Abr", time: "15:00", type: "Treino", team: "Sub-20", modality: "Rugby" },
  { id: uid(), name: "Jogo Amistoso vs Titans", date: "13 Abr", time: "10:00", type: "Jogo", team: "Adulto", modality: "Rugby" },
  { id: uid(), name: "Treino Físico", date: "15 Abr", time: "16:00", type: "Treino", team: "Sub-15", modality: "Futebol" },
  { id: uid(), name: "Campeonato Regional", date: "20 Abr", time: "09:00", type: "Jogo", team: "Adulto", modality: "Basquete" },
];

const defaultProjects: Project[] = [
  { id: uid(), name: "Edital Lei de Incentivo 2025", status: "Em andamento", progress: 65, deadline: "30 Jun 2025", partner: "Secretaria de Esportes" },
  { id: uid(), name: "Parceria Nike Comunidade", status: "Aprovado", progress: 100, deadline: "—", partner: "Nike Brasil" },
  { id: uid(), name: "Projeto Rugby nas Escolas", status: "Em análise", progress: 30, deadline: "15 Mai 2025", partner: "MEC" },
  { id: uid(), name: "Captação Atletas Sub-15", status: "Em andamento", progress: 45, deadline: "01 Jul 2025", partner: "CBRu" },
];

const defaultMessages: Message[] = [
  { id: uid(), title: "Treino cancelado terça", to: "Todos", date: "08 Abr", preview: "O treino de terça foi cancelado devido à chuva..." },
  { id: uid(), title: "Convocação jogo sábado", to: "Sub-20", date: "07 Abr", preview: "Todos os atletas Sub-20 devem comparecer às 8h..." },
  { id: uid(), title: "Reunião de pais", to: "Pais Sub-15", date: "05 Abr", preview: "Convocamos reunião para dia 12/04 às 19h..." },
  { id: uid(), title: "Pagamento abril", to: "Inadimplentes", date: "03 Abr", preview: "Lembramos que a mensalidade de abril vence dia 10..." },
];

const defaultPayments: Payment[] = [
  { id: uid(), name: "Lucas Silva", month: "Abril", value: "R$ 120", status: "Pago" },
  { id: uid(), name: "Pedro Santos", month: "Abril", value: "R$ 120", status: "Pendente" },
  { id: uid(), name: "Ana Costa", month: "Abril", value: "R$ 80", status: "Pago" },
  { id: uid(), name: "João Oliveira", month: "Abril", value: "R$ 120", status: "Pago" },
  { id: uid(), name: "Maria Souza", month: "Março", value: "R$ 120", status: "Atrasado" },
  { id: uid(), name: "Rafael Mendes", month: "Abril", value: "R$ 80", status: "Pendente" },
];

export function AppProvider({ children }: { children: ReactNode }) {
  const [teams, setTeams] = useState<Team[]>(defaultTeams);
  const [athletes, setAthletes] = useState<Athlete[]>(defaultAthletes);
  const [events, setEvents] = useState<Event[]>(defaultEvents);
  const [projects, setProjects] = useState<Project[]>(defaultProjects);
  const [messages, setMessages] = useState<Message[]>(defaultMessages);
  const [payments, setPayments] = useState<Payment[]>(defaultPayments);

  const addTeam = (t: Omit<Team, "id">) => setTeams((prev) => [{ ...t, id: uid() }, ...prev]);
  const addAthlete = (a: Omit<Athlete, "id">) => setAthletes((prev) => [{ ...a, id: uid() }, ...prev]);
  const addEvent = (e: Omit<Event, "id">) => setEvents((prev) => [{ ...e, id: uid() }, ...prev]);
  const addProject = (p: Omit<Project, "id">) => setProjects((prev) => [{ ...p, id: uid() }, ...prev]);
  const addMessage = (m: Omit<Message, "id">) => setMessages((prev) => [{ ...m, id: uid() }, ...prev]);
  const addPayment = (p: Omit<Payment, "id">) => setPayments((prev) => [{ ...p, id: uid() }, ...prev]);

  return (
    <AppContext.Provider value={{ teams, addTeam, athletes, addAthlete, events, addEvent, projects, addProject, messages, addMessage, payments, addPayment }}>
      {children}
    </AppContext.Provider>
  );
}

export function useApp() {
  const ctx = useContext(AppContext);
  if (!ctx) throw new Error("useApp must be used within AppProvider");
  return ctx;
}
