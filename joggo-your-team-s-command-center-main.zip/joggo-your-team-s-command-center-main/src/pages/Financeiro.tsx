import { useState } from "react";
import { DollarSign, AlertTriangle, CheckCircle, QrCode } from "lucide-react";
import AppLayout from "@/components/AppLayout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Progress } from "@/components/ui/progress";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { useApp } from "@/contexts/AppContext";

const Financeiro = () => {
  const { payments } = useApp();
  const [pixOpen, setPixOpen] = useState(false);
  const [pixTarget, setPixTarget] = useState("");

  const paid = payments.filter((p) => p.status === "Pago").length;
  const total = payments.length;

  const openPix = (name: string) => {
    setPixTarget(name);
    setPixOpen(true);
  };

  return (
    <AppLayout>
      <div className="mx-auto max-w-7xl space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold text-foreground">Financeiro</h1>
            <p className="text-muted-foreground">Controle de mensalidades e cobranças</p>
          </div>
          <Button className="gap-2 bg-success hover:bg-success/90 text-success-foreground" onClick={() => openPix("Todos")}>
            <QrCode className="h-4 w-4" /> Gerar Cobrança PIX
          </Button>
        </div>

        <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
          <Card>
            <CardContent className="flex items-center gap-4 p-6">
              <div className="rounded-lg bg-success/10 p-3"><CheckCircle className="h-6 w-6 text-success" /></div>
              <div><p className="text-sm text-muted-foreground">Recebido</p><p className="text-2xl font-bold text-foreground">R$ 1.280</p></div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="flex items-center gap-4 p-6">
              <div className="rounded-lg bg-destructive/10 p-3"><AlertTriangle className="h-6 w-6 text-destructive" /></div>
              <div><p className="text-sm text-muted-foreground">Inadimplência</p><p className="text-2xl font-bold text-foreground">R$ 320</p></div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="flex items-center gap-4 p-6">
              <div className="rounded-lg bg-primary/10 p-3"><DollarSign className="h-6 w-6 text-primary" /></div>
              <div>
                <p className="text-sm text-muted-foreground">Taxa de Pagamento</p>
                <p className="text-2xl font-bold text-foreground">{total > 0 ? Math.round((paid / total) * 100) : 0}%</p>
                <Progress value={total > 0 ? (paid / total) * 100 : 0} className="mt-2 h-2" />
              </div>
            </CardContent>
          </Card>
        </div>

        <Card>
          <CardHeader><CardTitle>Mensalidades</CardTitle></CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Atleta</TableHead>
                  <TableHead>Mês</TableHead>
                  <TableHead>Valor</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Ação</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {payments.map((p) => (
                  <TableRow key={p.id}>
                    <TableCell className="font-medium">{p.name}</TableCell>
                    <TableCell>{p.month}</TableCell>
                    <TableCell>{p.value}</TableCell>
                    <TableCell>
                      <Badge variant={p.status === "Pago" ? "default" : "destructive"}>{p.status}</Badge>
                    </TableCell>
                    <TableCell>
                      {p.status !== "Pago" && (
                        <Button size="sm" variant="outline" className="gap-1" onClick={() => openPix(p.name)}>
                          <QrCode className="h-3 w-3" /> PIX
                        </Button>
                      )}
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>

        <Dialog open={pixOpen} onOpenChange={setPixOpen}>
          <DialogContent className="max-w-sm">
            <DialogHeader><DialogTitle>Cobrança PIX</DialogTitle></DialogHeader>
            <div className="flex flex-col items-center gap-4 py-4">
              <div className="w-48 h-48 bg-muted rounded-xl flex items-center justify-center border-2 border-dashed border-primary/30">
                <div className="grid grid-cols-5 gap-1 p-4">
                  {Array.from({ length: 25 }).map((_, i) => (
                    <div key={i} className={`w-3 h-3 rounded-sm ${Math.random() > 0.4 ? "bg-foreground" : "bg-transparent"}`} />
                  ))}
                </div>
              </div>
              <p className="text-sm text-muted-foreground text-center">QR Code gerado para: <strong>{pixTarget}</strong></p>
              <p className="text-xs text-muted-foreground">Valor: R$ 120,00 • Vencimento: 10/04/2025</p>
              <div className="w-full space-y-2 pt-2">
                <p className="text-xs font-semibold text-muted-foreground">Histórico recente</p>
                <div className="text-xs space-y-1">
                  <div className="flex justify-between"><span>05/04 — Lucas Silva</span><Badge variant="default" className="text-[10px]">Pago</Badge></div>
                  <div className="flex justify-between"><span>03/04 — Ana Costa</span><Badge variant="default" className="text-[10px]">Pago</Badge></div>
                  <div className="flex justify-between"><span>01/04 — João Oliveira</span><Badge variant="default" className="text-[10px]">Pago</Badge></div>
                </div>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      </div>
    </AppLayout>
  );
};

export default Financeiro;
