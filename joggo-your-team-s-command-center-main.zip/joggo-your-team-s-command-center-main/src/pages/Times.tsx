import { useState } from "react";
import { Shield, Plus, Users, Search, Dribbble, CircleDot } from "lucide-react";
import AppLayout from "@/components/AppLayout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { useApp, Modality } from "@/contexts/AppContext";

const modalityIcons: Record<string, string> = {
  Futebol: "⚽", Basquete: "🏀", Vôlei: "🏐", Rugby: "🏉", Handebol: "🤾", Futsal: "⚽",
};

const modalityColors: Record<string, string> = {
  Futebol: "bg-success", Basquete: "bg-destructive", Vôlei: "bg-secondary", Rugby: "bg-primary", Handebol: "bg-accent", Futsal: "bg-success",
};

const Times = () => {
  const { teams, addTeam } = useApp();
  const [open, setOpen] = useState(false);
  const [search, setSearch] = useState("");
  const [modalityFilter, setModalityFilter] = useState("all");
  const [newName, setNewName] = useState("");
  const [newCategory, setNewCategory] = useState("Sub-15");
  const [newModality, setNewModality] = useState<Modality>("Futebol");

  const filtered = teams.filter((t) => {
    const matchSearch = t.name.toLowerCase().includes(search.toLowerCase());
    const matchModality = modalityFilter === "all" || t.modality === modalityFilter;
    return matchSearch && matchModality;
  });

  const handleAdd = () => {
    if (!newName.trim()) return;
    addTeam({ name: newName, category: newCategory, modality: newModality, athletes: 0 });
    setNewName("");
    setOpen(false);
  };

  return (
    <AppLayout>
      <div className="mx-auto max-w-7xl space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold text-foreground">Times</h1>
            <p className="text-muted-foreground">Gerencie suas equipes e categorias</p>
          </div>
          <Dialog open={open} onOpenChange={setOpen}>
            <DialogTrigger asChild>
              <Button className="gap-2"><Plus className="h-4 w-4" /> Novo Time</Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader><DialogTitle>Novo Time</DialogTitle></DialogHeader>
              <div className="space-y-4 pt-2">
                <div><Label>Nome</Label><Input value={newName} onChange={(e) => setNewName(e.target.value)} placeholder="Nome do time" /></div>
                <div><Label>Categoria</Label>
                  <Select value={newCategory} onValueChange={setNewCategory}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Sub-15">Sub-15</SelectItem>
                      <SelectItem value="Sub-20">Sub-20</SelectItem>
                      <SelectItem value="Adulto">Adulto</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div><Label>Modalidade</Label>
                  <Select value={newModality} onValueChange={(v) => setNewModality(v as Modality)}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>
                      {(["Futebol", "Basquete", "Vôlei", "Rugby", "Handebol", "Futsal"] as Modality[]).map((m) => (
                        <SelectItem key={m} value={m}>{modalityIcons[m]} {m}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <Button onClick={handleAdd} className="w-full">Criar Time</Button>
              </div>
            </DialogContent>
          </Dialog>
        </div>

        <div className="flex flex-col gap-3 sm:flex-row">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
            <Input placeholder="Buscar time..." className="pl-9" value={search} onChange={(e) => setSearch(e.target.value)} />
          </div>
          <Select value={modalityFilter} onValueChange={setModalityFilter}>
            <SelectTrigger className="w-[160px]"><SelectValue placeholder="Modalidade" /></SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Todas</SelectItem>
              {(["Futebol", "Basquete", "Vôlei", "Rugby", "Handebol", "Futsal"] as Modality[]).map((m) => (
                <SelectItem key={m} value={m}>{m}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {filtered.map((team) => (
            <Card key={team.id} className="hover:shadow-md transition-shadow cursor-pointer">
              <CardHeader className="flex-row items-center gap-4 space-y-0">
                <div className={`${modalityColors[team.modality] || "bg-primary"} rounded-xl p-3 text-primary-foreground flex items-center justify-center text-xl`}>
                  {modalityIcons[team.modality] || "🏅"}
                </div>
                <div className="flex-1">
                  <CardTitle className="text-lg">{team.name}</CardTitle>
                  <div className="flex gap-2 mt-1">
                    <Badge variant="secondary">{team.category}</Badge>
                    <Badge variant="outline">{team.modality}</Badge>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <div className="flex items-center gap-2 text-muted-foreground">
                  <Users className="h-4 w-4" />
                  <span className="text-sm">{team.athletes} atletas</span>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </AppLayout>
  );
};

export default Times;
