import { Users, BarChart3, CalendarDays, TrendingUp } from "lucide-react";
import AppLayout from "@/components/AppLayout";
import WelcomeCard from "@/components/dashboard/WelcomeCard";
import MetricCard from "@/components/dashboard/MetricCard";
import PerformanceChart from "@/components/dashboard/PerformanceChart";
import FrequencyChart from "@/components/dashboard/FrequencyChart";
import AthleteRanking from "@/components/dashboard/AthleteRanking";
import UpcomingEvents from "@/components/dashboard/UpcomingEvents";
import AttendanceStatus from "@/components/dashboard/AttendanceStatus";

const Index = () => {
  return (
    <AppLayout>
      <div className="mx-auto max-w-7xl space-y-6">
        {/* Welcome */}
        <WelcomeCard />

        {/* Metrics */}
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
          <MetricCard
            title="Total de Atletas"
            value="32"
            change="+3 este mês"
            changeType="positive"
            icon={Users}
          />
          <MetricCard
            title="Presença Média"
            value="87%"
            change="+5% vs mês anterior"
            changeType="positive"
            icon={BarChart3}
          />
          <MetricCard
            title="Próximo Evento"
            value="Terça"
            change="15:00 — Treino Tático"
            changeType="neutral"
            icon={CalendarDays}
          />
          <MetricCard
            title="Performance"
            value="82"
            change="+8 pontos"
            changeType="positive"
            icon={TrendingUp}
          />
        </div>

        {/* Charts + Ranking */}
        <div className="grid grid-cols-1 gap-6 lg:grid-cols-3">
          <div className="lg:col-span-2 space-y-6">
            <PerformanceChart />
            <FrequencyChart />
          </div>
          <div className="space-y-6">
            <AthleteRanking />
          </div>
        </div>

        {/* Events + Attendance */}
        <div className="grid grid-cols-1 gap-6 md:grid-cols-2">
          <UpcomingEvents />
          <AttendanceStatus />
        </div>
      </div>
    </AppLayout>
  );
};

export default Index;
