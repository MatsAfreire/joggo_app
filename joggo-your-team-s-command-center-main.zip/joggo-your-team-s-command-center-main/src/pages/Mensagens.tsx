import { useState } from "react";
import { Send } from "lucide-react";
import AppLayout from "@/components/AppLayout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useApp } from "@/contexts/AppContext";
import { toast } from "sonner";

const Mensagens = () => {
  const { messages, addMessage } = useApp();
  const [dest, setDest] = useState("Todos");
  const [title, setTitle] = useState("");
  const [body, setBody] = useState("");

  const handleSend = () => {
    if (!title.trim() || !body.trim()) {
      toast.error("Preencha título e mensagem");
      return;
    }
    const today = new Date();
    const dateStr = `${String(today.getDate()).padStart(2, "0")} ${["Jan","Fev","Mar","Abr","Mai","Jun","Jul","Ago","Set","Out","Nov","Dez"][today.getMonth()]}`;
    addMessage({ title, to: dest, date: dateStr, preview: body.slice(0, 60) + (body.length > 60 ? "..." : "") });
    setTitle("");
    setBody("");
    toast.success("Aviso enviado!");
  };

  return (
    <AppLayout>
      <div className="mx-auto max-w-7xl space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold text-foreground">Mensagens</h1>
            <p className="text-muted-foreground">Central de avisos para pais e atletas</p>
          </div>
        </div>

        <div className="grid grid-cols-1 gap-6 lg:grid-cols-3">
          <Card className="lg:col-span-1">
            <CardHeader><CardTitle className="text-base">Novo Aviso</CardTitle></CardHeader>
            <CardContent className="space-y-4">
              <Input placeholder="Título do aviso" value={title} onChange={(e) => setTitle(e.target.value)} />
              <Select value={dest} onValueChange={setDest}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="Todos">Todos</SelectItem>
                  <SelectItem value="Sub-15">Sub-15</SelectItem>
                  <SelectItem value="Sub-20">Sub-20</SelectItem>
                  <SelectItem value="Adulto">Adulto</SelectItem>
                  <SelectItem value="Pais">Pais</SelectItem>
                </SelectContent>
              </Select>
              <Textarea placeholder="Escreva sua mensagem..." rows={4} value={body} onChange={(e) => setBody(e.target.value)} />
              <Button className="w-full gap-2" onClick={handleSend}><Send className="h-4 w-4" /> Enviar Aviso</Button>
            </CardContent>
          </Card>

          <div className="lg:col-span-2 space-y-3">
            {messages.map((m) => (
              <Card key={m.id} className="hover:shadow-md transition-shadow cursor-pointer">
                <CardContent className="flex items-start gap-4 p-4">
                  <div className="rounded-lg bg-primary/10 p-2 mt-1"><Send className="h-4 w-4 text-primary" /></div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between">
                      <p className="font-semibold text-foreground truncate">{m.title}</p>
                      <span className="text-xs text-muted-foreground whitespace-nowrap ml-2">{m.date}</span>
                    </div>
                    <Badge variant="outline" className="mt-1 text-xs">{m.to}</Badge>
                    <p className="text-sm text-muted-foreground mt-1 truncate">{m.preview}</p>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </div>
    </AppLayout>
  );
};

export default Mensagens;
