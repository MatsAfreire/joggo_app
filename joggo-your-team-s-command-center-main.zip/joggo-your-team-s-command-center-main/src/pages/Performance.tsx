import AppLayout from "@/components/AppLayout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useState } from "react";
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, RadarChart, PolarGrid, PolarAngleAxis, PolarRadiusAxis, Radar } from "recharts";

const evolutionData = [
  { month: "Jan", fisico: 60, tecnico: 55 },
  { month: "Fev", fisico: 65, tecnico: 60 },
  { month: "Mar", fisico: 70, tecnico: 68 },
  { month: "Abr", fisico: 78, tecnico: 72 },
  { month: "Mai", fisico: 82, tecnico: 80 },
  { month: "Jun", fisico: 85, tecnico: 84 },
];

const radarData = [
  { skill: "Velocidade", value: 85 },
  { skill: "Força", value: 78 },
  { skill: "Resistência", value: 90 },
  { skill: "Técnica", value: 72 },
  { skill: "Tático", value: 80 },
  { skill: "Disciplina", value: 88 },
];

const Performance = () => {
  const [athlete, setAthlete] = useState("lucas");

  return (
    <AppLayout>
      <div className="mx-auto max-w-7xl space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold text-foreground">Performance</h1>
            <p className="text-muted-foreground">Evolução física e técnica dos atletas</p>
          </div>
          <Select value={athlete} onValueChange={setAthlete}>
            <SelectTrigger className="w-[200px]"><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value="lucas">Lucas Silva</SelectItem>
              <SelectItem value="pedro">Pedro Santos</SelectItem>
              <SelectItem value="ana">Ana Costa</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
          <Card>
            <CardHeader><CardTitle>Evolução Mensal</CardTitle></CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <LineChart data={evolutionData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                  <XAxis dataKey="month" stroke="hsl(var(--muted-foreground))" fontSize={12} />
                  <YAxis stroke="hsl(var(--muted-foreground))" fontSize={12} />
                  <Tooltip />
                  <Line type="monotone" dataKey="fisico" stroke="hsl(var(--primary))" strokeWidth={2} name="Físico" />
                  <Line type="monotone" dataKey="tecnico" stroke="hsl(var(--secondary))" strokeWidth={2} name="Técnico" />
                </LineChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>

          <Card>
            <CardHeader><CardTitle>Habilidades</CardTitle></CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <RadarChart data={radarData}>
                  <PolarGrid stroke="hsl(var(--border))" />
                  <PolarAngleAxis dataKey="skill" fontSize={12} stroke="hsl(var(--muted-foreground))" />
                  <PolarRadiusAxis fontSize={10} />
                  <Radar name="Habilidades" dataKey="value" stroke="hsl(var(--primary))" fill="hsl(var(--primary))" fillOpacity={0.2} />
                </RadarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </div>
      </div>
    </AppLayout>
  );
};

export default Performance;
