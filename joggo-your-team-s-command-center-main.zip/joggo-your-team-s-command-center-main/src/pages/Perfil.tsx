import { User, Mail, Phone, Shield, Edit } from "lucide-react";
import AppLayout from "@/components/AppLayout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";

const Perfil = () => (
  <AppLayout>
    <div className="mx-auto max-w-3xl space-y-6">
      <Card>
        <CardContent className="flex flex-col items-center gap-4 p-8 sm:flex-row sm:items-start">
          <Avatar className="h-20 w-20">
            <AvatarFallback className="bg-primary text-primary-foreground text-2xl">TR</AvatarFallback>
          </Avatar>
          <div className="flex-1 text-center sm:text-left">
            <h1 className="text-2xl font-bold text-foreground">Treinador Rafael</h1>
            <p className="text-muted-foreground">Treinador Principal • JOGGO Rugby</p>
            <div className="flex flex-wrap justify-center gap-2 mt-3 sm:justify-start">
              <Badge>Admin</Badge>
              <Badge variant="secondary">Treinador</Badge>
            </div>
          </div>
          <Button variant="outline" className="gap-2"><Edit className="h-4 w-4" /> Editar</Button>
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
        <Card>
          <CardHeader><CardTitle className="text-base">Contato</CardTitle></CardHeader>
          <CardContent className="space-y-3">
            <div className="flex items-center gap-3 text-sm"><Mail className="h-4 w-4 text-muted-foreground" /><span>rafael@joggo.app</span></div>
            <div className="flex items-center gap-3 text-sm"><Phone className="h-4 w-4 text-muted-foreground" /><span>(11) 99999-0000</span></div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader><CardTitle className="text-base">Equipes</CardTitle></CardHeader>
          <CardContent className="space-y-3">
            <div className="flex items-center gap-3 text-sm"><Shield className="h-4 w-4 text-primary" /><span>JOGGO Sub-20</span></div>
            <div className="flex items-center gap-3 text-sm"><Shield className="h-4 w-4 text-secondary" /><span>JOGGO Adulto</span></div>
          </CardContent>
        </Card>
      </div>
    </div>
  </AppLayout>
);

export default Perfil;
