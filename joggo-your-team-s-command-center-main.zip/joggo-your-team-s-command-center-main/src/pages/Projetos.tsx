import { useState } from "react";
import { Plus, FolderKanban, ExternalLink } from "lucide-react";
import AppLayout from "@/components/AppLayout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useApp } from "@/contexts/AppContext";

const statusColor = (s: string) => {
  if (s === "Aprovado") return "default";
  if (s === "Em andamento") return "secondary";
  return "outline";
};

const Projetos = () => {
  const { projects, addProject } = useApp();
  const [open, setOpen] = useState(false);
  const [newName, setNewName] = useState("");
  const [newPartner, setNewPartner] = useState("");
  const [newDeadline, setNewDeadline] = useState("");
  const [newStatus, setNewStatus] = useState("Em andamento");

  const handleAdd = () => {
    if (!newName.trim()) return;
    addProject({ name: newName, partner: newPartner || "—", deadline: newDeadline || "—", status: newStatus, progress: 0 });
    setNewName("");
    setNewPartner("");
    setNewDeadline("");
    setOpen(false);
  };

  return (
    <AppLayout>
      <div className="mx-auto max-w-7xl space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold text-foreground">Projetos</h1>
            <p className="text-muted-foreground">Editais, parcerias e projetos sociais</p>
          </div>
          <Dialog open={open} onOpenChange={setOpen}>
            <DialogTrigger asChild>
              <Button className="gap-2"><Plus className="h-4 w-4" /> Novo Projeto</Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader><DialogTitle>Novo Projeto</DialogTitle></DialogHeader>
              <div className="space-y-4 pt-2">
                <div><Label>Nome</Label><Input value={newName} onChange={(e) => setNewName(e.target.value)} placeholder="Nome do projeto" /></div>
                <div><Label>Parceiro</Label><Input value={newPartner} onChange={(e) => setNewPartner(e.target.value)} placeholder="Parceiro/Instituição" /></div>
                <div><Label>Prazo</Label><Input value={newDeadline} onChange={(e) => setNewDeadline(e.target.value)} placeholder="30 Jun 2025" /></div>
                <div><Label>Status</Label>
                  <Select value={newStatus} onValueChange={setNewStatus}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Em andamento">Em andamento</SelectItem>
                      <SelectItem value="Em análise">Em análise</SelectItem>
                      <SelectItem value="Aprovado">Aprovado</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <Button onClick={handleAdd} className="w-full">Criar Projeto</Button>
              </div>
            </DialogContent>
          </Dialog>
        </div>

        <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
          {projects.map((p) => (
            <Card key={p.id} className="hover:shadow-md transition-shadow">
              <CardHeader className="flex-row items-start justify-between space-y-0">
                <div className="flex items-center gap-3">
                  <div className="rounded-lg bg-secondary/10 p-2"><FolderKanban className="h-5 w-5 text-secondary" /></div>
                  <div>
                    <CardTitle className="text-base">{p.name}</CardTitle>
                    <p className="text-sm text-muted-foreground">{p.partner}</p>
                  </div>
                </div>
                <Badge variant={statusColor(p.status) as any}>{p.status}</Badge>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="flex items-center justify-between text-sm">
                  <span className="text-muted-foreground">Progresso</span>
                  <span className="font-medium text-foreground">{p.progress}%</span>
                </div>
                <Progress value={p.progress} className="h-2" />
                <div className="flex items-center justify-between text-sm">
                  <span className="text-muted-foreground">Prazo: {p.deadline}</span>
                  <Button variant="ghost" size="sm" className="gap-1 text-primary"><ExternalLink className="h-3 w-3" />Detalhes</Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </AppLayout>
  );
};

export default Projetos;
