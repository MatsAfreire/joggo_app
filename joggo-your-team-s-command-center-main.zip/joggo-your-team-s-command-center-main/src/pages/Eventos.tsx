import { useState } from "react";
import { Plus, CalendarDays, Trophy } from "lucide-react";
import AppLayout from "@/components/AppLayout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Calendar } from "@/components/ui/calendar";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useApp, Modality } from "@/contexts/AppContext";

const scoringRules: Record<Modality, { label: string; points: number }[]> = {
  Rugby: [
    { label: "Try", points: 5 },
    { label: "Conversão", points: 2 },
    { label: "Penal", points: 3 },
  ],
  Futebol: [
    { label: "Gol", points: 1 },
  ],
  Basquete: [
    { label: "Cesta 2pts", points: 2 },
    { label: "Cesta 3pts", points: 3 },
    { label: "Lance livre", points: 1 },
  ],
  Vôlei: [
    { label: "Set", points: 1 },
  ],
  Handebol: [
    { label: "Gol", points: 1 },
  ],
  Futsal: [
    { label: "Gol", points: 1 },
  ],
};

const modalityEmoji: Record<string, string> = {
  Rugby: "🏉", Futebol: "⚽", Basquete: "🏀", Vôlei: "🏐", Handebol: "🤾", Futsal: "⚽",
};

const SumulaAdaptavel = () => {
  const [modality, setModality] = useState<Modality>("Rugby");
  const [homeScore, setHomeScore] = useState(0);
  const [awayScore, setAwayScore] = useState(0);

  const rules = scoringRules[modality];

  const ScorePanel = ({ label, score, setScore }: { label: string; score: number; setScore: (v: number) => void }) => (
    <Card>
      <CardHeader className="pb-2">
        <CardTitle className="text-center text-lg">{label}</CardTitle>
        <p className="text-center text-4xl font-bold text-primary">{score}</p>
      </CardHeader>
      <CardContent className="flex flex-wrap justify-center gap-2">
        {rules.map((r) => (
          <Button key={r.label} size="sm" onClick={() => setScore(score + r.points)} className="bg-primary hover:bg-primary/90">
            {r.label} +{r.points}
          </Button>
        ))}
        <Button size="sm" variant="outline" onClick={() => setScore(0)}>Zerar</Button>
      </CardContent>
    </Card>
  );

  return (
    <div className="space-y-4">
      <div className="flex items-center gap-3">
        <Label>Modalidade:</Label>
        <Select value={modality} onValueChange={(v) => { setModality(v as Modality); setHomeScore(0); setAwayScore(0); }}>
          <SelectTrigger className="w-[180px]"><SelectValue /></SelectTrigger>
          <SelectContent>
            {Object.keys(scoringRules).map((m) => (
              <SelectItem key={m} value={m}>{modalityEmoji[m]} {m}</SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
        <ScorePanel label="🏠 Casa" score={homeScore} setScore={setHomeScore} />
        <ScorePanel label="✈️ Visitante" score={awayScore} setScore={setAwayScore} />
      </div>
    </div>
  );
};

const Eventos = () => {
  const { events, addEvent } = useApp();
  const [date, setDate] = useState<Date | undefined>(new Date());
  const [open, setOpen] = useState(false);
  const [newName, setNewName] = useState("");
  const [newDate, setNewDate] = useState("");
  const [newTime, setNewTime] = useState("");
  const [newType, setNewType] = useState<"Treino" | "Jogo" | "Reunião">("Treino");
  const [newTeam, setNewTeam] = useState("Sub-20");
  const [newModality, setNewModality] = useState<Modality>("Futebol");

  const handleAdd = () => {
    if (!newName.trim()) return;
    addEvent({ name: newName, date: newDate || "—", time: newTime || "—", type: newType, team: newTeam, modality: newModality });
    setNewName("");
    setOpen(false);
  };

  return (
    <AppLayout>
      <div className="mx-auto max-w-7xl space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold text-foreground">Eventos</h1>
            <p className="text-muted-foreground">Calendário de jogos, treinos e súmulas</p>
          </div>
          <Dialog open={open} onOpenChange={setOpen}>
            <DialogTrigger asChild>
              <Button className="gap-2"><Plus className="h-4 w-4" /> Novo Evento</Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader><DialogTitle>Novo Evento</DialogTitle></DialogHeader>
              <div className="space-y-4 pt-2">
                <div><Label>Nome</Label><Input value={newName} onChange={(e) => setNewName(e.target.value)} placeholder="Nome do evento" /></div>
                <div className="grid grid-cols-2 gap-3">
                  <div><Label>Data</Label><Input value={newDate} onChange={(e) => setNewDate(e.target.value)} placeholder="10 Abr" /></div>
                  <div><Label>Horário</Label><Input value={newTime} onChange={(e) => setNewTime(e.target.value)} placeholder="15:00" /></div>
                </div>
                <div><Label>Tipo</Label>
                  <Select value={newType} onValueChange={(v) => setNewType(v as any)}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Treino">Treino</SelectItem>
                      <SelectItem value="Jogo">Jogo</SelectItem>
                      <SelectItem value="Reunião">Reunião</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div><Label>Equipe</Label><Input value={newTeam} onChange={(e) => setNewTeam(e.target.value)} placeholder="Sub-20" /></div>
                <div><Label>Modalidade</Label>
                  <Select value={newModality} onValueChange={(v) => setNewModality(v as Modality)}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>
                      {(["Futebol", "Basquete", "Vôlei", "Rugby", "Handebol", "Futsal"] as Modality[]).map((m) => (
                        <SelectItem key={m} value={m}>{m}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <Button onClick={handleAdd} className="w-full">Criar Evento</Button>
              </div>
            </DialogContent>
          </Dialog>
        </div>

        <Tabs defaultValue="calendario">
          <TabsList>
            <TabsTrigger value="calendario"><CalendarDays className="mr-2 h-4 w-4" />Calendário</TabsTrigger>
            <TabsTrigger value="sumula"><Trophy className="mr-2 h-4 w-4" />Súmula</TabsTrigger>
          </TabsList>

          <TabsContent value="calendario" className="space-y-4 mt-4">
            <div className="grid grid-cols-1 gap-6 lg:grid-cols-3">
              <Card className="lg:col-span-1">
                <CardContent className="p-4 flex justify-center">
                  <Calendar mode="single" selected={date} onSelect={setDate} />
                </CardContent>
              </Card>
              <div className="lg:col-span-2 space-y-3">
                {events.map((e) => (
                  <Card key={e.id} className="hover:shadow-md transition-shadow">
                    <CardContent className="flex items-center gap-4 p-4">
                      <div className="rounded-lg bg-primary/10 p-3">
                        <CalendarDays className="h-5 w-5 text-primary" />
                      </div>
                      <div className="flex-1">
                        <p className="font-semibold text-foreground">{e.name}</p>
                        <p className="text-sm text-muted-foreground">{e.date} às {e.time} • {e.team} {e.modality ? `• ${e.modality}` : ""}</p>
                      </div>
                      <Badge variant={e.type === "Jogo" ? "default" : "secondary"}>{e.type}</Badge>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>
          </TabsContent>

          <TabsContent value="sumula" className="mt-4">
            <SumulaAdaptavel />
          </TabsContent>
        </Tabs>
      </div>
    </AppLayout>
  );
};

export default Eventos;
