const JoggoLogo = ({ collapsed = false }: { collapsed?: boolean }) => {
  return (
    <div className="flex items-center gap-2 px-2">
      <div className="flex h-9 w-9 items-center justify-center rounded-lg gradient-primary">
        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" className="text-primary-foreground">
          <circle cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="2" />
          <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
          <circle cx="12" cy="12" r="3" fill="currentColor" />
        </svg>
      </div>
      {!collapsed && (
        <span className="text-lg font-bold tracking-[0.25em] text-sidebar-foreground">
          J O G G O
        </span>
      )}
    </div>
  );
};

export default JoggoLogo;
