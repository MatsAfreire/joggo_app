import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Star } from "lucide-react";

const athletes = [
  { name: "Lucas Silva", position: "Atacante", score: 95, initials: "LS", highlight: true },
  { name: "Ana Santos", position: "Meio-campo", score: 92, initials: "AS", highlight: false },
  { name: "Pedro Oliveira", position: "Zagueiro", score: 88, initials: "PO", highlight: false },
  { name: "Maria Costa", position: "Lateral", score: 85, initials: "MC", highlight: false },
  { name: "João Lima", position: "Goleiro", score: 82, initials: "JL", highlight: false },
];

const AthleteRanking = () => {
  return (
    <div className="rounded-xl bg-card p-5 shadow-card animate-fade-in">
      <div className="mb-4 flex items-center justify-between">
        <div>
          <h3 className="text-base font-semibold text-card-foreground">Ranking de Atletas</h3>
          <p className="text-xs text-muted-foreground">Top 5 da semana</p>
        </div>
        <Star className="h-5 w-5 text-secondary" />
      </div>

      <div className="space-y-3">
        {athletes.map((athlete, index) => (
          <div
            key={athlete.name}
            className={`flex items-center gap-3 rounded-lg p-2.5 transition-colors ${
              athlete.highlight ? "gradient-subtle" : "hover:bg-muted/50"
            }`}
          >
            <span className="flex h-6 w-6 items-center justify-center rounded-md bg-muted text-xs font-bold text-muted-foreground">
              {index + 1}
            </span>
            <Avatar className="h-8 w-8">
              <AvatarFallback className="text-xs font-semibold bg-primary/10 text-primary">
                {athlete.initials}
              </AvatarFallback>
            </Avatar>
            <div className="flex-1 min-w-0">
              <p className="text-sm font-medium text-card-foreground truncate">{athlete.name}</p>
              <p className="text-xs text-muted-foreground">{athlete.position}</p>
            </div>
            <span className="text-sm font-bold text-primary">{athlete.score}</span>
          </div>
        ))}
      </div>
    </div>
  );
};

export default AthleteRanking;
