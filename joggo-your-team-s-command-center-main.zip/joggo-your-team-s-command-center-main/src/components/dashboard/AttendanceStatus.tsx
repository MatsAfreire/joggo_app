import { CheckCircle, XCircle, Clock } from "lucide-react";

const statuses = [
  { name: "Lucas Silva", status: "confirmado" as const },
  { name: "Ana Santos", status: "confirmado" as const },
  { name: "Pedro Oliveira", status: "pendente" as const },
  { name: "Maria Costa", status: "confirmado" as const },
  { name: "João Lima", status: "ausente" as const },
  { name: "Carlos Ferreira", status: "pendente" as const },
];

const statusConfig = {
  confirmado: { icon: CheckCircle, label: "Confirmado", className: "text-success" },
  pendente: { icon: Clock, label: "Pendente", className: "text-secondary" },
  ausente: { icon: XCircle, label: "Ausente", className: "text-destructive" },
};

const AttendanceStatus = () => {
  return (
    <div className="rounded-xl bg-card p-5 shadow-card animate-fade-in">
      <h3 className="text-base font-semibold text-card-foreground mb-4">Status de Presença</h3>
      <div className="space-y-2.5">
        {statuses.map((s) => {
          const config = statusConfig[s.status];
          const Icon = config.icon;
          return (
            <div key={s.name} className="flex items-center justify-between py-1">
              <span className="text-sm text-card-foreground">{s.name}</span>
              <div className={`flex items-center gap-1.5 ${config.className}`}>
                <Icon className="h-4 w-4" />
                <span className="text-xs font-medium">{config.label}</span>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};

export default AttendanceStatus;
