import { CalendarDays, MapPin, Clock } from "lucide-react";

const events = [
  {
    title: "Treino Tático",
    date: "Terça, 15:00",
    location: "Campo Municipal",
    type: "treino" as const,
  },
  {
    title: "Jogo vs. Unidos FC",
    date: "Sábado, 10:00",
    location: "Estádio Regional",
    type: "jogo" as const,
  },
  {
    title: "Avaliação Física",
    date: "Segunda, 08:00",
    location: "Centro Esportivo",
    type: "avaliacao" as const,
  },
];

const typeStyles = {
  treino: "border-l-primary",
  jogo: "border-l-success",
  avaliacao: "border-l-secondary",
};

const UpcomingEvents = () => {
  return (
    <div className="rounded-xl bg-card p-5 shadow-card animate-fade-in">
      <div className="mb-4 flex items-center gap-2">
        <CalendarDays className="h-5 w-5 text-primary" />
        <h3 className="text-base font-semibold text-card-foreground">Próximos Eventos</h3>
      </div>

      <div className="space-y-3">
        {events.map((event) => (
          <div
            key={event.title}
            className={`rounded-lg border-l-4 bg-muted/40 p-3 ${typeStyles[event.type]}`}
          >
            <p className="text-sm font-semibold text-card-foreground">{event.title}</p>
            <div className="mt-1.5 flex flex-col gap-1">
              <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
                <Clock className="h-3 w-3" />
                <span>{event.date}</span>
              </div>
              <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
                <MapPin className="h-3 w-3" />
                <span>{event.location}</span>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default UpcomingEvents;
