import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts";

const data = [
  { name: "Jan", performance: 65 },
  { name: "Fev", performance: 72 },
  { name: "Mar", performance: 68 },
  { name: "Abr", performance: 78 },
  { name: "Mai", performance: 82 },
  { name: "Jun", performance: 85 },
  { name: "Jul", performance: 90 },
];

const PerformanceChart = () => {
  return (
    <div className="rounded-xl bg-card p-5 shadow-card animate-fade-in">
      <div className="mb-4 flex items-center justify-between">
        <div>
          <h3 className="text-base font-semibold text-card-foreground">Evolução do Time</h3>
          <p className="text-xs text-muted-foreground">Performance geral nos últimos 7 meses</p>
        </div>
      </div>
      <div className="h-[220px]">
        <ResponsiveContainer width="100%" height="100%">
          <AreaChart data={data}>
            <defs>
              <linearGradient id="perfGrad" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor="hsl(217, 91%, 53%)" stopOpacity={0.3} />
                <stop offset="100%" stopColor="hsl(217, 91%, 53%)" stopOpacity={0} />
              </linearGradient>
            </defs>
            <CartesianGrid strokeDasharray="3 3" stroke="hsl(214, 32%, 91%)" vertical={false} />
            <XAxis dataKey="name" fontSize={12} tickLine={false} axisLine={false} stroke="hsl(215, 16%, 47%)" />
            <YAxis fontSize={12} tickLine={false} axisLine={false} stroke="hsl(215, 16%, 47%)" />
            <Tooltip
              contentStyle={{
                backgroundColor: "hsl(0, 0%, 100%)",
                border: "1px solid hsl(214, 32%, 91%)",
                borderRadius: "8px",
                fontSize: "12px",
              }}
            />
            <Area
              type="monotone"
              dataKey="performance"
              stroke="hsl(217, 91%, 53%)"
              strokeWidth={2.5}
              fill="url(#perfGrad)"
            />
          </AreaChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
};

export default PerformanceChart;
