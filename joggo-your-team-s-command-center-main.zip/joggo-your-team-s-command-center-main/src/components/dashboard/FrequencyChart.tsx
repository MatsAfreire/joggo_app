import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts";

const data = [
  { day: "Seg", presenca: 18 },
  { day: "Ter", presenca: 22 },
  { day: "Qua", presenca: 15 },
  { day: "Qui", presenca: 25 },
  { day: "Sex", presenca: 20 },
  { day: "Sáb", presenca: 28 },
  { day: "Dom", presenca: 12 },
];

const FrequencyChart = () => {
  return (
    <div className="rounded-xl bg-card p-5 shadow-card animate-fade-in">
      <div className="mb-4">
        <h3 className="text-base font-semibold text-card-foreground">Frequência Semanal</h3>
        <p className="text-xs text-muted-foreground">Presença nos treinos por dia</p>
      </div>
      <div className="h-[220px]">
        <ResponsiveContainer width="100%" height="100%">
          <BarChart data={data}>
            <CartesianGrid strokeDasharray="3 3" stroke="hsl(214, 32%, 91%)" vertical={false} />
            <XAxis dataKey="day" fontSize={12} tickLine={false} axisLine={false} stroke="hsl(215, 16%, 47%)" />
            <YAxis fontSize={12} tickLine={false} axisLine={false} stroke="hsl(215, 16%, 47%)" />
            <Tooltip
              contentStyle={{
                backgroundColor: "hsl(0, 0%, 100%)",
                border: "1px solid hsl(214, 32%, 91%)",
                borderRadius: "8px",
                fontSize: "12px",
              }}
            />
            <Bar dataKey="presenca" fill="hsl(263, 70%, 58%)" radius={[6, 6, 0, 0]} barSize={32} />
          </BarChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
};

export default FrequencyChart;
