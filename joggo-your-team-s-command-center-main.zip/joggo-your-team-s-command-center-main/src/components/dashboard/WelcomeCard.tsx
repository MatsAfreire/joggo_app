import { CalendarPlus } from "lucide-react";
import { Button } from "@/components/ui/button";

const WelcomeCard = () => {
  return (
    <div className="relative overflow-hidden rounded-xl gradient-primary p-6 md:p-8 text-primary-foreground">
      <div className="relative z-10">
        <p className="text-sm font-medium opacity-90">Bom dia, Roberto 👋</p>
        <h1 className="mt-1 text-2xl font-bold">Bem-vindo ao JOGGO</h1>
        <p className="mt-2 text-sm opacity-80 max-w-md">
          Próximo treino: <span className="font-semibold">Terça-feira, 15:00</span> — Campo Municipal
        </p>
        <Button
          size="sm"
          className="mt-4 bg-card/20 hover:bg-card/30 text-primary-foreground border-0 backdrop-blur-sm"
        >
          <CalendarPlus className="h-4 w-4 mr-2" />
          Criar evento
        </Button>
      </div>
      {/* Decorative circles */}
      <div className="absolute -right-8 -top-8 h-40 w-40 rounded-full bg-card/5" />
      <div className="absolute -right-4 bottom-0 h-24 w-24 rounded-full bg-card/5" />
    </div>
  );
};

export default WelcomeCard;
